// stwórz klasę MouseRecorder, która
// - po wywołaniu metody .record() przez 30sekund co 100ms zapisuje w localStorage aktualną pozycję myszki oraz scrolla ekranu
// - po wywołaniu metody .play() zmienia kursor na cancel ora odtwarza zapis z localStorage

class PositionRecorder{
    constructor(){
        // ...
    }

    record(){

    }

    play(){

    }
}