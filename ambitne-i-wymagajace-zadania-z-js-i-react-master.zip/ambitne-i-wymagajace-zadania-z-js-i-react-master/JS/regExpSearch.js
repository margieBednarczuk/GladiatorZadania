// stwórz 3 regexpy
// - pierwszy, który pozwoli Ci zaznaczyć wszystkie hashtagi w tekscie 
// -- #nauka #tag

// - drugi, który znajdzie imiona wg wzorca, że 1 litera jest duża, a potem małe, +/- kolejne słowa frazy 
// -- Marek, Aleksandra, Magda, Paweł

// - trzeci, który pojedyczne podane znaki interpunktycje i specjalne - !@#$%^&*-=+_?~
// -- lorem # ipsum - to znajdzie
// -- lorem@ipsum - tego nie znajdzie
