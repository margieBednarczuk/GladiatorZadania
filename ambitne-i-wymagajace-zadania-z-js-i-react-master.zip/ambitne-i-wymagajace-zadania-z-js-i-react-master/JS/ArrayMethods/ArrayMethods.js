// Programowanie funkcyjne oraz arraye

// w Javascript Arraye posiadają swoje metody
// .forEach
// .map
// .entries
// .filter
// .reduce
// .every
// .some

// skopiuj identyczne działanie tych metod za pomocą pętli for lub while
// w funkcjach

const forEachFn = (array, callback) => {}

const mapFn = (array, callback) => {}

const entriesFn = (array, callback) => {}

const filterFn = (array, callback) => {}

const reduceFn = (array, callback, inital) => {}

const everyFn = (array, callback) => {}

const someFn = (array, callback) => {}
