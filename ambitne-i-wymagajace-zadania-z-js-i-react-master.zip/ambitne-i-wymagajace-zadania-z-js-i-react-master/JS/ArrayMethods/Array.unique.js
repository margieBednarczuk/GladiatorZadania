
// Stwórz metodę arraya .unique w JS
// const arr = [0,1,2,'test',3,'7',11,'test']

// która będzie mieć 1 działanie:
// - arr.unique() => [0,1,2,'test',3,'7',11]

Array.prototype.unique = function(){
    // return ...
}