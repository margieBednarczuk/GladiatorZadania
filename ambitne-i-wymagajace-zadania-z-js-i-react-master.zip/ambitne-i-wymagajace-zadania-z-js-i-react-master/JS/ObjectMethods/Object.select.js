
// Stwórz customową metodę dla Objekt .select, 
// która jest high order function i zwraca nowy obiekt

// argumenty callback(key,value)
// które wykonują się alfabetycznie dla każdego klucza
// - jeśli callback zwróci true dany klucz i wartość będzie zwrócona

Object.prototype.select = function(callback){
    // return ...
}