// tworząc funkcję videoStepOnScroll dołączonej do listenera window.onscroll
function videoStepOnScroll(event){

}
// stwórz dla klasy taga video z klasą .step-play
// efekt taki jak na stronie poniżej (tło odtwarza film podklatkowo na scrollu)
// https://c3t-tech.com/mini-fibre-wall-outlet/