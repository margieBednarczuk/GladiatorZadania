// zrób dowolną animację oraz odpal ją w trybie infinite
// - odpal animację na init strony

// stwórz webworkera do generowania danych
// - puść webworkera na init strony
// - wygeneruj na webworkerze pomiędzy 100 000 a 1 000 000 wpisów w postaci obiektów o minimum 5 dowolnych kluczach (mogą być hashe)
// - po wygenerowaniu danych wrzucaj je w porcji co 1000 wpisów co 1 sekundę do window.randomItems


// to zadanie będzie dobrze rozwiązane wtedy
// kiedy animacja nie będzie się ciąć :D 
