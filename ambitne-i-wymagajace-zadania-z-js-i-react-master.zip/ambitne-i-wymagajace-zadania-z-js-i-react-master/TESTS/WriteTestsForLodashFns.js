// Testowanie jest w modzie i pomaga programistom upewnić się czy czegoś nie schrzanili

// ściągnij bibliotekę lodash (https://lodash.com/) i wyciągnij z niej nastepujące funkcje:
// - _.chunk
// - _.concat
// - _.uniqBy
// - _.head
// - _.remove
// - _.tail
// - _.shuffle
// - _.zip
// - _.mapKeys
// i przeczytaj uważnie co robią te fukcję


// korzystając z biblioteki jest.js oraz chai.js stwórz
// - min 2 testy opisujące poprawne działanie:
// -- "funkcja pokazuje ostatnie 5 elementów arraya"

// - min 2 testy opisujące niepoprawne działanie
// -- jeśli do funkcji, która wymaga obiektu wrzucimy array, funkcja wyrzuci nam error lub komentarz





