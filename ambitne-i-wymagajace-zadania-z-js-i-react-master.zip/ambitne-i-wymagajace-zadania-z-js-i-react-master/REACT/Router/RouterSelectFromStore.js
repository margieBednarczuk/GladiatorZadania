
// Stwórz Store Reduxa:
// - store połączony z aplikacją, który zawiera array z itemami


// Stwórz Router gdzie masz 2 routy:
// - <ItemsListView> na  /items - pokazujący listę itemów
// - <ItemDetailView> na  /items/${id} - pokazyjący jeden item


// stwórz taką funkcjonalność w aplikacji, aby 
// przy zmianie routa lub na GET `/items/${id}` 
// wybierało ze store item o odpowiednim indexie
// i podawało item do routa <ItemDetailView> w propie item


