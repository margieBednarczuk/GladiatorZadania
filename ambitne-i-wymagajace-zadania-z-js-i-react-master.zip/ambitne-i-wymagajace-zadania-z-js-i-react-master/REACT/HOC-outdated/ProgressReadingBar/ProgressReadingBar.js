// Przygotuj HOCa withProgressReadingBar, który:
// - tworzy nad komponentem, który przyjmuje progress bar, który jest niebieski o wysokości 5px
// - progress bar odzwierciedla swoją długością wysokość przeskrolowanego elementu child
// - progress bar powienien być sticky do górnej krawędzi ekranu w obrębie elementu child
// - owrapowany komponent powinien mieć maksymalnie wysokość 50% wysokości ekranu

const withProgressReadingBar = (Component)=>{}