// jeden człowiek to:
// - imię, nazwisko, wiek, płeć,
// - twarz, który będzie losowo wygenerowaną przez AI obrazkiem twarzy człowieka
// -- zbadaj https://www.thispersondoesnotexist.com

// stwórz zbiory imion, nazwisk, płci, wieków

// na postawie zbiorów stwórz fukcję
const generatePerson = () => {}
// stwórz funkcję generuje człowieka (jako obiekt) o losowych parametrach

const people = [] // stwórz listę 100 ludzi

// stwórz komponent, który prezentuje wszystkie informacje o człowieku
const SinglePerson = (props)=>{
    return null
}

// stwórz listę, która zaprezentuje pierwszych 10 ludzi
const MoreAndMorePeople = ({
    items
}) => {
    // po doscrolowaniu do końca listy, lista ma załadować
    // kolejną dziesiątkę ludzi do pokazywanych
    // jeśli pierwszych 100 ludzi (podstawowa wartość propa 'items') się skończy
    // lista ma wygenerować świeżych 10 ludzi i ich pokazać
    return null
}