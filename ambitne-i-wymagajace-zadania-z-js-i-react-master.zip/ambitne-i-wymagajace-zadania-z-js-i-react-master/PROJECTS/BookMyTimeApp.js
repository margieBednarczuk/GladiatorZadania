// Stwórz małą aplikację z użyciem kalendarza o nazwie BookMyTimeApp

// Kontekst:
// Przychodzi do Ciebie nietechniczny klient i chce zamówić apkę, którą sobie wymyślił
// Postaraj się zrealizować jego pomysł wzbogadacjąc swoje portfolio

// Działanie, czyli
// "to ma działać tak":
// - chciałbym aby, kalendarz powinien być zintegrowany z moim kalendarzem google
// - podziel dzień na 55min okienka do rezerwacji z 5 minutową przerwą między każdym spotkaniem
// - można rezerwować godziny na spotkania od 8 do 18 od poniedziału do piątku, ale bez środy
// - klientu musi podać swoje imię, mail oraz powód spotkania
// - jak klient doda spotkanie, to ma zobaczyć, że zarezerwował to spotkanie
// - i ja i klient mamy dostać maile z informacjami odnośnie spotkania zaraz po zarezerwowaniu

// Wygląd, czyli
// "ja to widzę tak":
// - klient widzi cały ten i przysżły miesiąc obok siebie
// - jeśli dany termin jest zajęty pokazuje się szare pole
// - wolny termin jest zielony i mogę w niego kliknąć i otworzy mu się okienko do umówienia spotkania

// Proponowany stack technologiczny: React + Redux + GoogleMaps/OpenMaps + Jest